# BA890-Analytics-Practicum
Research Paper as part of Analytics Practicum Course
